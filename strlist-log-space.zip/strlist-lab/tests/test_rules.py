from strlist_lab.models import Event
from strlist_lab.rules import brute_force, success_after_failures


def gagal(ip):
    return Event("t", None, "u", ip, "failure")


def ok(ip):
    return Event("t", None, "u", ip, "success")


def test_ambang_tepat():
    ev = [gagal("1.1.1.1")] * 3
    assert len(brute_force(ev, 3)) == 1
    assert brute_force(ev, 4) == []


def test_ip_kosong_tidak_dihitung():
    assert brute_force([gagal(None)] * 10, 3) == []


def test_urutan_menurun():
    ev = [gagal("1.1.1.1")] * 3 + [gagal("2.2.2.2")] * 5
    assert [f.ip for f in brute_force(ev)] == ["2.2.2.2", "1.1.1.1"]


def test_sukses_setelah_gagal_harus_berurutan():
    assert len(success_after_failures([gagal("a")] * 3 + [ok("a")], 3)) == 1
    assert success_after_failures([ok("a")] + [gagal("a")] * 3, 3) == []
