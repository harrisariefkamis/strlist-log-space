from strlist_lab.cli import main


def test_cli_ingest_dan_report(tmp_path, fx, capsys):
    dbp = str(tmp_path / "t.db")
    assert main(["--db", dbp, "init-db"]) == 0
    assert main(["--db", dbp, "ingest", str(fx("okta_bad.json")), "--label", "malicious"]) == 0
    assert main(["--db", dbp, "report"]) == 0
    assert "okta_bad.json" in capsys.readouterr().out
