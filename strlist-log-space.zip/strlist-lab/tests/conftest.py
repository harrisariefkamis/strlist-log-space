from pathlib import Path

import pytest

FIX = Path(__file__).parent / "fixtures"
EXTERNAL = Path(__file__).parent.parent / "data" / "external" / "security-log-samples"


@pytest.fixture
def fx():
    return lambda nama: FIX / nama


@pytest.fixture
def conn():
    from strlist_lab import db
    c = db.connect(":memory:")
    yield c
    c.close()
