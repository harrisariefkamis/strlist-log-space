from strlist_lab.loaders import load_json_records
from strlist_lab.normalize import detect_source, normalize_authlog, normalize_records


def test_deteksi_sumber(fx):
    assert detect_source(load_json_records(fx("okta_bad.json"))[0]) == "okta"
    assert detect_source(load_json_records(fx("azure_bad.json"))[0]) == "azure"
    assert detect_source(load_json_records(fx("wazuh_bad.json"))[0]) == "wazuh"
    assert detect_source({"x": 1}) is None


def test_azure_error_code(fx):
    ev, _ = normalize_records(load_json_records(fx("azure_bad.json")))
    assert [e.outcome for e in ev] == ["failure"] * 5 + ["success"]


def test_wazuh_string_jadi_data_dan_list_jadi_tags(fx):
    ev, _ = normalize_records(load_json_records(fx("wazuh_bad.json")))
    assert ev[0].outcome == "failure" and ev[0].user == "root"
    assert ev[0].tags == ("syslog", "sshd", "authentication_failed")
    assert ev[4].outcome == "other"  # baris non-sshd


def test_rekaman_tak_dikenal_dihitung(tmp_path):
    ev, lewat = normalize_records([{"x": 1}, {"y": 2}])
    assert ev == [] and lewat == 2


def test_authlog_baris_rusak_dilewati(fx):
    ev, lewat = normalize_authlog(fx("authlog_bad.log").read_text().splitlines())
    assert len(ev) == 5 and lewat == 1
    assert [e.user for e in ev][:3] == ["root", "pi", "oracle"]
