"""Uji pada dataset publik (logtriage-cyber/security-log-samples, CC BY 4.0).

Otomatis dilewati bila data/external/security-log-samples tidak ada.
"""
import hashlib
import json

import pytest
from conftest import EXTERNAL

from strlist_lab import pipeline

pytestmark = [pytest.mark.integration,
              pytest.mark.skipif(not EXTERNAL.exists(), reason="dataset belum diunduh")]

S = EXTERNAL / "samples"
PASANGAN = [
    ("okta/malicious/okta_credential_stuffing.json", "okta/benign/okta_normal_logins.json"),
    ("azure-ad-signin/malicious/azure_brute_force.json", "azure-ad-signin/benign/azure_normal_corporate.json"),
    ("wazuh/malicious/wazuh_brute_force.json", "wazuh/benign/wazuh_normal.json"),
    ("auth-log/malicious/authlog_brute_force.log", "auth-log/benign/authlog_normal.log"),
]


def test_manifest_sha256():
    manifest = json.loads((EXTERNAL / "manifest.json").read_text(encoding="utf-8"))
    for m in manifest:
        assert hashlib.sha256((EXTERNAL / m["path"]).read_bytes()).hexdigest() == m["sha256"], m["path"]


@pytest.mark.parametrize("bad,ok", PASANGAN)
def test_dua_arah(conn, bad, ok):
    assert pipeline.ingest_file(conn, S / bad, "malicious")["findings"] >= 1
    assert pipeline.ingest_file(conn, S / ok, "benign")["findings"] == 0
