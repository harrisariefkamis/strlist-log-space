from strlist_lab.parsers import parse_sshd_message, split_syslog


def test_split_syslog_memecah_baris_jadi_bagian():
    s = split_syslog("Jan  1 02:00:01 host-1 sshd[3821]: Failed password for root from 1.2.3.4 port 1 ssh2")
    assert s["waktu"] == "Jan 1 02:00:01"
    assert s["host"] == "host-1"
    assert s["proses"] == "sshd"


def test_baris_pendek_ditolak():
    assert split_syslog("baris rusak") is None


def test_failed_password_user_dan_ip():
    assert parse_sshd_message("Failed password for root from 1.2.3.4 port 22 ssh2") == ("failure", "root", "1.2.3.4")


def test_invalid_user_dengan_dua_bentuk():
    assert parse_sshd_message("Failed password for invalid user pi from 1.2.3.4 port 22 ssh2")[1] == "pi"
    assert parse_sshd_message("Invalid user oracle from 1.2.3.4 port 22") == ("failure", "oracle", "1.2.3.4")


def test_accepted_dan_pesan_lain():
    assert parse_sshd_message("Accepted publickey for deploy from 10.0.0.1 port 22")[0] == "success"
    assert parse_sshd_message("session opened for user root") == ("other", None, None)


def test_ip_tidak_valid_diabaikan():
    assert parse_sshd_message("Failed password for root from host.example port 22")[2] is None
