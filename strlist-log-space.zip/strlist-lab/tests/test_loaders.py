import json

import pytest

from strlist_lab.loaders import load_json_records


def test_array(fx):
    assert len(load_json_records(fx("okta_bad.json"))) == 5


def test_objek_berisi_list(fx):
    assert len(load_json_records(fx("azure_bad.json"))) == 6


def test_ndjson(fx):
    assert len(load_json_records(fx("wazuh_bad.json"))) == 5


def test_ndjson_baris_rusak_menyebut_nomor(tmp_path):
    p = tmp_path / "x.json"
    p.write_text('{"a": 1}\n{rusak}\n', encoding="utf-8")
    with pytest.raises(ValueError, match="baris 2"):
        load_json_records(p)


def test_objek_tunggal_dibungkus_list(tmp_path):
    p = tmp_path / "x.json"
    p.write_text(json.dumps({"a": 1}), encoding="utf-8")
    assert load_json_records(p) == [{"a": 1}]
