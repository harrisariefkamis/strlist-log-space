import pytest

from strlist_lab import db, pipeline

PASANGAN = [("okta_bad.json", "okta_ok.json"), ("azure_bad.json", "azure_ok.json"),
            ("wazuh_bad.json", "wazuh_ok.json"), ("authlog_bad.log", "authlog_ok.log")]


@pytest.mark.parametrize("bad,ok", PASANGAN)
def test_aturan_menyala_pada_berbahaya_dan_diam_pada_normal(conn, fx, bad, ok):
    assert pipeline.ingest_file(conn, fx(bad), "malicious")["findings"] >= 1
    assert pipeline.ingest_file(conn, fx(ok), "benign")["findings"] == 0


def test_ingest_idempoten(conn, fx):
    a = pipeline.ingest_file(conn, fx("okta_bad.json"), "malicious")
    b = pipeline.ingest_file(conn, fx("okta_bad.json"), "malicious")
    assert a["status"] == "baru" and b["status"] == "sudah ada"
    assert conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0] == 1


def test_label_tidak_valid(conn, fx):
    with pytest.raises(ValueError):
        pipeline.ingest_file(conn, fx("okta_bad.json"), "salah")


def test_ringkasan_dan_relasi(conn, fx):
    pipeline.ingest_file(conn, fx("azure_bad.json"), "malicious")
    row = db.summary(conn)[0]
    assert (row["events"], row["findings"]) == (6, 2)  # brute_force + success_after_failures
    conn.execute("DELETE FROM sources")
    assert conn.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 0  # ON DELETE CASCADE
