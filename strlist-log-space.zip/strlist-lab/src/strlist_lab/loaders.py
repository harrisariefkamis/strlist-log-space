"""Muat berkas JSON dalam tiga bentuk umum menjadi list of dict.

1. array JSON            : [ {...}, {...} ]
2. objek berisi list     : {"value": [ ... ]}  /  {"Records": [ ... ]}
3. NDJSON (satu objek per baris)
"""
from __future__ import annotations

import json
from pathlib import Path

KUNCI_LIST = ("value", "Records", "records", "items", "entries", "findings", "Findings")


def _buka(data) -> list[dict]:
    if isinstance(data, list):
        return [d for d in data if isinstance(d, dict)]
    if isinstance(data, dict):
        for k in KUNCI_LIST:
            if isinstance(data.get(k), list):
                return [d for d in data[k] if isinstance(d, dict)]
        for v in data.values():
            if isinstance(v, list) and v and all(isinstance(x, dict) for x in v):
                return v
        return [data]
    raise ValueError("bentuk JSON tidak didukung")


def load_json_records(path: str | Path) -> list[dict]:
    teks = Path(path).read_text(encoding="utf-8")
    try:
        return _buka(json.loads(teks))
    except json.JSONDecodeError:
        pass
    hasil: list[dict] = []
    for no, baris in enumerate(teks.splitlines(), start=1):
        if not baris.strip():
            continue
        try:
            obj = json.loads(baris)
        except json.JSONDecodeError as e:
            raise ValueError(f"{path}: baris {no} bukan JSON valid ({e.msg})") from e
        if isinstance(obj, dict):
            hasil.append(obj)
    return hasil
