"""Alur: berkas -> list -> Event -> aturan -> SQLite."""
from __future__ import annotations

import hashlib
import sqlite3
from pathlib import Path

from . import db, rules
from .loaders import load_json_records
from .normalize import normalize_authlog, normalize_records

LABEL = ("malicious", "benign", "unknown")


def ingest_file(conn: sqlite3.Connection, path: str | Path, label: str = "unknown",
                threshold: int = rules.AMBANG_DEFAULT) -> dict:
    if label not in LABEL:
        raise ValueError(f"label harus salah satu dari {LABEL}")
    p = Path(path)
    sha = hashlib.sha256(p.read_bytes()).hexdigest()
    sid = db.source_id_by_sha(conn, sha)
    if sid is not None:  # idempoten: berkas yang sama tidak dimasukkan dua kali
        return {"source_id": sid, "status": "sudah ada", "events": None, "findings": None}

    if p.suffix.lower() == ".json":
        events, dilewati = normalize_records(load_json_records(p))
    else:
        events, dilewati = normalize_authlog(p.read_text(encoding="utf-8").splitlines())
    findings = rules.run_all(events, threshold)
    sid = db.save_run(conn, p.name, label, sha, events, findings)
    return {"source_id": sid, "status": "baru", "events": len(events),
            "findings": len(findings), "dilewati": dilewati}
