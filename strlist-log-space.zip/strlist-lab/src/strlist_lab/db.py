"""SQLite: skema dan fungsi simpan/baca. Semua query memakai parameter (bukan f-string)."""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .models import Event, Finding

SKEMA = """
CREATE TABLE IF NOT EXISTS sources (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    label       TEXT NOT NULL CHECK (label IN ('malicious','benign','unknown')),
    sha256      TEXT NOT NULL UNIQUE,
    ingested_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
    id        INTEGER PRIMARY KEY,
    source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
    seq       INTEGER NOT NULL,
    ts        TEXT,
    user      TEXT,
    ip        TEXT,
    outcome   TEXT NOT NULL CHECK (outcome IN ('failure','success','other')),
    tags      TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS findings (
    id        INTEGER PRIMARY KEY,
    source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
    rule      TEXT NOT NULL,
    ip        TEXT NOT NULL,
    failures  INTEGER NOT NULL,
    detail    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_source ON events(source_id);
CREATE INDEX IF NOT EXISTS idx_events_ip ON events(ip);
"""


def connect(path: str | Path = ":memory:") -> sqlite3.Connection:
    if str(path) != ":memory:":
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    conn.executescript(SKEMA)
    return conn


def source_id_by_sha(conn: sqlite3.Connection, sha256: str) -> int | None:
    row = conn.execute("SELECT id FROM sources WHERE sha256 = ?", (sha256,)).fetchone()
    return row["id"] if row else None


def save_run(conn: sqlite3.Connection, name: str, label: str, sha256: str,
             events: list[Event], findings: list[Finding]) -> int:
    """Simpan satu berkas + event + temuan dalam satu transaksi."""
    with conn:
        cur = conn.execute(
            "INSERT INTO sources(name, label, sha256, ingested_at) VALUES (?,?,?,?)",
            (name, label, sha256, datetime.now(timezone.utc).isoformat(timespec="seconds")))
        sid = cur.lastrowid
        conn.executemany(
            "INSERT INTO events(source_id, seq, ts, user, ip, outcome, tags) VALUES (?,?,?,?,?,?,?)",
            [(sid, i, e.ts, e.user, e.ip, e.outcome, ",".join(e.tags))
             for i, e in enumerate(events)])
        conn.executemany(
            "INSERT INTO findings(source_id, rule, ip, failures, detail) VALUES (?,?,?,?,?)",
            [(sid, f.rule, f.ip, f.failures, f.detail) for f in findings])
    return sid


def summary(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute(
        """SELECT s.name, s.label,
                  (SELECT COUNT(*) FROM events   e WHERE e.source_id = s.id) AS events,
                  (SELECT COUNT(*) FROM findings f WHERE f.source_id = s.id) AS findings
           FROM sources s ORDER BY s.id""").fetchall()
