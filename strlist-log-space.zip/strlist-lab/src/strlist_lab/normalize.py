"""Ubah rekaman berbeda bentuk (Okta, Azure AD, Wazuh, auth.log) menjadi Event seragam."""
from __future__ import annotations

from .models import Event
from .parsers import parse_sshd_message, split_syslog


def detect_source(rec: dict) -> str | None:
    if "eventType" in rec and "outcome" in rec:
        return "okta"
    if "userPrincipalName" in rec and "status" in rec:
        return "azure"
    if "rule" in rec and "full_log" in rec:
        return "wazuh"
    return None


def _okta(rec: dict) -> Event:
    hasil = str(rec.get("outcome", {}).get("result", "")).upper()
    outcome = {"FAILURE": "failure", "SUCCESS": "success"}.get(hasil, "other")
    return Event("okta", rec.get("published"), rec.get("actor", {}).get("alternateId"),
                 rec.get("client", {}).get("ipAddress"), outcome)


def _azure(rec: dict) -> Event:
    kode = rec.get("status", {}).get("errorCode")
    outcome = "success" if kode == 0 else ("failure" if kode is not None else "other")
    return Event("azure", rec.get("createdDateTime"), rec.get("userPrincipalName"),
                 rec.get("ipAddress"), outcome)


def _wazuh(rec: dict) -> Event:
    sys = split_syslog(rec.get("full_log", ""))
    outcome, user, ip = ("other", None, None)
    if sys and sys["proses"] == "sshd":
        outcome, user, ip = parse_sshd_message(sys["pesan"])
    ip = ip or rec.get("data", {}).get("srcip")
    tags = tuple(rec.get("rule", {}).get("groups", []))
    return Event("wazuh", rec.get("timestamp"), user, ip, outcome, tags)


_PEMETAAN = {"okta": _okta, "azure": _azure, "wazuh": _wazuh}


def normalize_records(records: list[dict]) -> tuple[list[Event], int]:
    """Kembalikan (events, jumlah rekaman yang dilewati karena bentuk tak dikenal)."""
    events, dilewati = [], 0
    for rec in records:
        sumber = detect_source(rec)
        if sumber is None:
            dilewati += 1
            continue
        events.append(_PEMETAAN[sumber](rec))
    return events, dilewati


def normalize_authlog(baris_list: list[str]) -> tuple[list[Event], int]:
    events, dilewati = [], 0
    for baris in baris_list:
        if not baris.strip():
            continue
        s = split_syslog(baris)
        if s is None:
            dilewati += 1
            continue
        outcome, user, ip = ("other", None, None)
        if s["proses"] == "sshd":
            outcome, user, ip = parse_sshd_message(s["pesan"])
        events.append(Event("authlog", s["waktu"], user, ip, outcome))
    return events, dilewati
