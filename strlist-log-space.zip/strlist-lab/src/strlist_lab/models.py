from __future__ import annotations

from dataclasses import dataclass

OUTCOMES = ("failure", "success", "other")


@dataclass(frozen=True)
class Event:
    """Satu kejadian login yang sudah dinormalisasi dari format apa pun."""

    source: str           # okta | azure | wazuh | authlog
    ts: str | None
    user: str | None
    ip: str | None
    outcome: str          # failure | success | other
    tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class Finding:
    rule: str
    ip: str
    failures: int
    detail: str
