"""Parser string -> list -> dict untuk baris syslog/sshd (auth.log, full_log Wazuh)."""
from __future__ import annotations


def split_syslog(line: str) -> dict | None:
    """'Mar 15 02:00:01 web-01 sshd[3821]: Failed password ...' -> dict, atau None."""
    t = line.split()
    if len(t) < 6:
        return None
    return {
        "waktu": " ".join(t[:3]),
        "host": t[3],
        "proses": t[4].split("[")[0].rstrip(":"),
        "pesan": " ".join(t[5:]),
    }


def _ip_after_from(tokens: list[str]) -> str | None:
    if "from" not in tokens:
        return None
    i = tokens.index("from") + 1
    if i >= len(tokens):
        return None
    kandidat = tokens[i]
    return kandidat if kandidat.count(".") == 3 else None


def parse_sshd_message(pesan: str) -> tuple[str, str | None, str | None]:
    """Kembalikan (outcome, user, ip) dari pesan sshd. outcome: failure|success|other."""
    t = pesan.split()
    ip = _ip_after_from(t)
    if pesan.startswith("Failed password") and "for" in t:
        i = t.index("for") + 1
        if t[i:i + 2] == ["invalid", "user"]:
            i += 2
        return "failure", (t[i] if i < len(t) else None), ip
    if pesan.startswith("Invalid user") and len(t) >= 3:
        return "failure", t[2], ip
    if pesan.startswith("Accepted") and "for" in t:
        i = t.index("for") + 1
        return "success", (t[i] if i < len(t) else None), ip
    return "other", None, ip
