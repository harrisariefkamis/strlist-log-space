"""Aturan deteksi sederhana. Ambang adalah angka buatan sendiri, bukan standar baku."""
from __future__ import annotations

from collections import Counter

from .models import Event, Finding

AMBANG_DEFAULT = 3


def brute_force(events: list[Event], threshold: int = AMBANG_DEFAULT) -> list[Finding]:
    """IP dengan kegagalan login >= threshold."""
    hitung = Counter(e.ip for e in events if e.outcome == "failure" and e.ip)
    hasil = [Finding("brute_force", ip, n, f"{n} kegagalan dari {ip}")
             for ip, n in hitung.items() if n >= threshold]
    return sorted(hasil, key=lambda f: (-f.failures, f.ip))


def success_after_failures(events: list[Event], threshold: int = AMBANG_DEFAULT) -> list[Finding]:
    """Login berhasil setelah >= threshold kegagalan dari IP yang sama (urutan = urutan berkas)."""
    gagal: Counter = Counter()
    ditandai: dict[str, Finding] = {}
    for e in events:
        if not e.ip:
            continue
        if e.outcome == "failure":
            gagal[e.ip] += 1
        elif e.outcome == "success" and gagal[e.ip] >= threshold and e.ip not in ditandai:
            ditandai[e.ip] = Finding("success_after_failures", e.ip, gagal[e.ip],
                                     f"berhasil login setelah {gagal[e.ip]} kegagalan")
    return list(ditandai.values())


def run_all(events: list[Event], threshold: int = AMBANG_DEFAULT) -> list[Finding]:
    return brute_force(events, threshold) + success_after_failures(events, threshold)
