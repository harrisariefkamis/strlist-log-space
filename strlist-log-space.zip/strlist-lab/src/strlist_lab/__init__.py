"""strlist_lab: dari teks mentah menjadi data (string & list) + SQLite."""

__version__ = "0.1.0"
