from __future__ import annotations

import argparse
from pathlib import Path

from . import db, pipeline, rules

DB_DEFAULT = "data/strlab.db"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="strlab", description="Lab String & List + SQLite")
    ap.add_argument("--db", default=DB_DEFAULT, help=f"lokasi database (default {DB_DEFAULT})")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init-db", help="buat database dan tabel")

    p_in = sub.add_parser("ingest", help="masukkan satu atau banyak berkas log")
    p_in.add_argument("paths", nargs="+")
    p_in.add_argument("--label", choices=pipeline.LABEL, default="unknown")
    p_in.add_argument("--threshold", type=int, default=rules.AMBANG_DEFAULT)

    sub.add_parser("report", help="ringkasan per berkas")

    a = ap.parse_args(argv)
    conn = db.connect(a.db)
    if a.cmd == "init-db":
        print(f"Database siap: {Path(a.db).resolve()}")
    elif a.cmd == "ingest":
        for path in a.paths:
            r = pipeline.ingest_file(conn, path, a.label, a.threshold)
            print(f"{Path(path).name}: {r}")
    elif a.cmd == "report":
        print(f"{'berkas':36} {'label':10} {'event':>6} {'temuan':>7}")
        for r in db.summary(conn):
            print(f"{r['name']:36} {r['label']:10} {r['events']:>6} {r['findings']:>7}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
